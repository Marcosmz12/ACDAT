export interface TaskModel {
    id: number;
    title: string;
    completed: boolean;
}
